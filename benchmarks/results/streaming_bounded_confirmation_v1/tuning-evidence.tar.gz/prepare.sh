#!/usr/bin/env bash
set -euo pipefail
cd /home/davidcondrey/hms-streaming-bounded
export RAYON_NUM_THREADS=8
export HMS_BOUNDED_DATA=/home/davidcondrey/hms-streaming-peak/datasets/msturing-30m-prefix-3m.fbin
export HMS_BOUNDED_QUERIES=/home/davidcondrey/hms-streaming-peak/datasets/msturing-30m-queries.fbin
export HMS_BOUNDED_ROWS=1000000 HMS_BOUNDED_ACTION=prepare
binary=$(cat binary.txt)
for capacity in 1000000 250000 500000; do
    export HMS_BOUNDED_CAPACITY=$capacity
    export HMS_BOUNDED_DIRECTORY=$PWD/fixture-1000000-$capacity
    nice -n 19 taskset -c 16,17 "$binary" bounded_consolidation_probe --ignored --nocapture --test-threads=1 > "evidence/prepare-1000000-$capacity.log" 2>&1
done
touch prepare-complete

#!/usr/bin/env bash
set -euo pipefail
cd /home/davidcondrey/hms-streaming-bounded
for capacity in 250000 500000; do
    for round in 1 2 3; do
        bash pair.sh 1000000 "$capacity" "$round" 512 128,256,512 256,512
    done
done
touch grid-complete

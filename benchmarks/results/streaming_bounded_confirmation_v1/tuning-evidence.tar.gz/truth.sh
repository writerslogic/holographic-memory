#!/usr/bin/env bash
set -euo pipefail
cd /home/davidcondrey/hms-streaming-bounded
rows=$1
start=$2
shift 2
export OPENBLAS_NUM_THREADS=2 OMP_NUM_THREADS=2
systemd-run --user --scope -q --unit="hms-bounded-truth-$rows-$start" \
  -p MemoryMax=3G -p MemorySwapMax=0 \
  nice -n 19 taskset -c 16,17 uv run --no-project --with numpy python oracle.py \
  --data /home/davidcondrey/hms-streaming-peak/datasets/msturing-30m-prefix-3m.fbin \
  --queries /home/davidcondrey/hms-streaming-peak/datasets/msturing-30m-queries.fbin \
  --rows "$rows" --start "$start" --output truth --capacities "$@" \
  > "evidence/truth-$rows-$start.log" 2>&1

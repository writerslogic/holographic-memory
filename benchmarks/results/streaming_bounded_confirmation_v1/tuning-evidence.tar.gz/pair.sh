#!/usr/bin/env bash
set -euo pipefail
cd /home/davidcondrey/hms-streaming-bounded
rows=$1
capacity=$2
round=$3
start=${4:-512}
candidate_efs=${5:-128,256,512}
base_efs=${6:-256,512}
export HMS_BOUNDED_LOCKED=1
cleanup() {
    for arm in global segments; do
        unit="hms-bounded-$rows-$capacity-$round-$arm-$start.scope"
        if systemctl --user --quiet is-active "$unit"; then
            systemctl --user stop "$unit"
        fi
    done
}
trap cleanup EXIT
exec 9>/home/davidcondrey/hms-timing.lock
flock -w 1800 9
if ((round % 2 == 1)); then
    timeout --signal=TERM --kill-after=10s 830s bash -c '
      bash run.sh run "$1" "$1" "$1-$2-$3-global-$4" "$4" "$6"
      bash run.sh run "$1" "$2" "$1-$2-$3-segments-$4" "$4" "$5"
    ' _ "$rows" "$capacity" "$round" "$start" "$candidate_efs" "$base_efs"
else
    timeout --signal=TERM --kill-after=10s 830s bash -c '
      bash run.sh run "$1" "$2" "$1-$2-$3-segments-$4" "$4" "$5"
      bash run.sh run "$1" "$1" "$1-$2-$3-global-$4" "$4" "$6"
    ' _ "$rows" "$capacity" "$round" "$start" "$candidate_efs" "$base_efs"
fi

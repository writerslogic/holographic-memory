#!/usr/bin/env bash
set -euo pipefail
cd /home/davidcondrey/hms-streaming-bounded
export RAYON_NUM_THREADS=8
export HMS_BOUNDED_DATA=/home/davidcondrey/hms-streaming-peak/datasets/msturing-30m-prefix-3m.fbin
export HMS_BOUNDED_QUERIES=/home/davidcondrey/hms-streaming-peak/datasets/msturing-30m-queries.fbin
mode=$1
rows=$2
capacity=$3
label=$4
export HMS_BOUNDED_ROWS=$rows HMS_BOUNDED_CAPACITY=$capacity
export HMS_BOUNDED_QUERY_START=${5:-512} HMS_BOUNDED_EFS=${6:-128,256,512}
export HMS_BOUNDED_ACTION=$mode
binary=$(cat binary.txt)
if [[ $mode == prepare ]]; then
    export HMS_BOUNDED_DIRECTORY=$PWD/fixture-$rows-$capacity
    nice -n 19 taskset -c 0-7 "$binary" bounded_consolidation_probe --ignored --nocapture --test-threads=1 > "evidence/$label.log" 2>&1
elif [[ $mode == run ]]; then
    export HMS_BOUNDED_DIRECTORY=$PWD/work-$label
    export HMS_BOUNDED_OUTPUT=$PWD/evidence/$label
    export BOUNDED_BINARY=$binary BOUNDED_FIXTURE=$PWD/fixture-$rows-$capacity
    if [[ ${HMS_BOUNDED_LOCKED:-0} != 1 ]]; then
        exec 9>/home/davidcondrey/hms-timing.lock
        flock -w 1800 9
    fi
    available_kib=$(awk '$1 == "MemAvailable:" {print $2}' /proc/meminfo)
    printf '{"available_memory_kib":%s}\n' "$available_kib" > "evidence/$label.preflight.json"
    if ((available_kib < 10485760)); then
        printf 'Less than10GiB available; no measurement started.\n' >&2
        exit 75
    fi
    timeout --signal=TERM --kill-after=10s 830s systemd-run --user --scope -q \
      --unit="hms-bounded-$label" -p RuntimeMaxSec=820s \
      -p MemoryMax=8G -p MemorySwapMax=0 \
      bash -c 'set -euo pipefail
        cp -a --reflink=never "$BOUNDED_FIXTURE" "$HMS_BOUNDED_DIRECTORY"
        /usr/bin/time -v taskset -c 0-7 "$BOUNDED_BINARY" bounded_consolidation_probe --ignored --nocapture --test-threads=1' \
      > "evidence/$label.log" 2>&1
else
    exit 2
fi

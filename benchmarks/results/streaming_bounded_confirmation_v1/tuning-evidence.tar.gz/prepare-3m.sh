#!/usr/bin/env bash
set -euo pipefail
cd /home/davidcondrey/hms-streaming-bounded
available_kib=$(awk '$1 == "MemAvailable:" {print $2}' /proc/meminfo)
printf '{"available_memory_kib":%s}\n' "$available_kib" > prepare-3m-preflight.json
if ((available_kib < 12582912)); then
    printf 'Less than 12 GiB available; no preparation started.\n' >&2
    exit 75
fi
export RAYON_NUM_THREADS=8
export HMS_BOUNDED_DATA=/home/davidcondrey/hms-streaming-peak/datasets/msturing-30m-prefix-3m.fbin
export HMS_BOUNDED_QUERIES=/home/davidcondrey/hms-streaming-peak/datasets/msturing-30m-queries.fbin
export HMS_BOUNDED_ROWS=3000000 HMS_BOUNDED_ACTION=prepare
binary=$(cat binary.txt)
for capacity in 3000000 250000; do
    export HMS_BOUNDED_CAPACITY=$capacity
    export HMS_BOUNDED_DIRECTORY=$PWD/fixture-3000000-$capacity
    nice -n 19 taskset -c 16,17 "$binary" bounded_consolidation_probe --ignored --nocapture --test-threads=1 > "evidence/prepare-3000000-$capacity.log" 2>&1
done
touch prepare-3m-complete

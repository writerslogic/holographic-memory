#!/usr/bin/env bash
set -euo pipefail
cd /home/davidcondrey/hms-streaming-bounded
export OPENBLAS_NUM_THREADS=2 OMP_NUM_THREADS=2
for rows in 1000000 3000000; do
    available_kib=$(awk '$1 == "MemAvailable:" {print $2}' /proc/meminfo)
    printf '{"available_memory_kib":%s}\n' "$available_kib" > "evidence/truth-$rows-640-preflight.json"
    if ((available_kib < 6291456)); then
        printf 'Less than 6 GiB available; no oracle started.\n' >&2
        exit 75
    fi
    systemd-run --user --scope -q --unit="hms-bounded-truth-$rows-640" \
      -p MemoryMax=3G -p MemorySwapMax=0 \
      nice -n 19 taskset -c 12,13 uv run --no-project --with numpy python oracle.py \
      --data /home/davidcondrey/hms-streaming-peak/datasets/msturing-30m-prefix-3m.fbin \
      --queries /home/davidcondrey/hms-streaming-peak/datasets/msturing-30m-queries.fbin \
      --rows "$rows" --start 640 --output truth --capacities 250000 \
      > "evidence/truth-$rows-640.log" 2>&1
done
touch truth-heldout-complete

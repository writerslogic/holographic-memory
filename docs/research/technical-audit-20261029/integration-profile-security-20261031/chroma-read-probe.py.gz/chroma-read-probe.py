import json
import tempfile

import chromadb
from chromadb.api.types import Documents, EmbeddingFunction, Embeddings
from chromadb.utils.embedding_functions import register_embedding_function
from writerslogic_warm_sdk.importers.sources.chroma import ChromaSource

calls = []
armed = False


@register_embedding_function
class Guard(EmbeddingFunction[Documents]):
    def __call__(self, input: Documents) -> Embeddings:
        raise AssertionError("Importer must not compute embeddings")

    @staticmethod
    def name() -> str:
        return "warm_audit_guard"

    def get_config(self):
        return {"model_name": "untrusted-fixture", "trust_remote_code": True}

    @staticmethod
    def build_from_config(config):
        if armed:
            calls.append(config)
            raise RuntimeError("Embedding configuration execution blocked by probe")
        return Guard()


with tempfile.TemporaryDirectory() as directory:
    client = chromadb.PersistentClient(path=directory)
    collection = client.create_collection("guarded", embedding_function=Guard())
    collection.add(ids=["one"], documents=["retained text"], embeddings=[[1.0, 0.0]],
                   metadatas=[{"kind": "fixture"}], uris=["https://invalid.example/not-fetched"])
    armed = True
    source = ChromaSource(path=directory)
    try:
        count = source.count()
        rows = list(source.records())
    finally:
        source.close()
    assert count == 1 and len(rows) == 1
    assert rows[0].id == "one" and rows[0].text == "retained text"
    assert not calls, calls
    try:
        _ = collection.configuration
    except ValueError as exc:
        assert "Embedding configuration execution blocked by probe" in str(exc)
    else:
        raise AssertionError("Positive control did not activate configuration loader")
    assert len(calls) == 1, calls
    print(json.dumps({"chromadb": chromadb.__version__, "imported_records": len(rows),
                      "configuration_execution_during_import": 0,
                      "positive_control_executions": len(calls)}))

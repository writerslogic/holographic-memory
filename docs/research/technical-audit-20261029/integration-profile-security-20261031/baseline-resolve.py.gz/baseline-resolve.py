import json, pathlib, subprocess, tomllib
root=pathlib.Path(__file__).resolve().parent
results=[]
for p in sorted(root.glob('*/pyproject.toml')):
    with (p.parent/'resolve.log').open('w') as log:
        try:
            r=subprocess.run(['uvx','--from','uv==0.13.6','uv','lock','--directory',str(p.parent)],stdout=log,stderr=subprocess.STDOUT,timeout=90)
            item={'extra':p.parent.name,'exit_code':r.returncode}
        except subprocess.TimeoutExpired:
            item={'extra':p.parent.name,'timeout':True}
    if item.get('exit_code')==0:
        item['packages']=len(tomllib.loads((p.parent/'uv.lock').read_text())['package'])
    results.append(item)
    (root/'resolution-summary.json').write_text(json.dumps(results,indent=2)+'\n')
    print(item,flush=True)

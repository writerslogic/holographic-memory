#[path = "../delta_rows.rs"]
mod delta_rows;

fn main() -> std::io::Result<()> {
    let root = tempfile::tempdir()?;
    fastrand::seed(20261030);
    let occupied = tempfile::tempdir_in(root.path())?;
    fastrand::seed(20261030);
    match tempfile::tempfile_in(root.path()) {
        Ok(_) => println!("file creation with occupied directory name succeeded"),
        Err(e) => println!("file creation with occupied directory name: {e:?}"),
    }
    tempfile::env::override_temp_dir(root.path()).unwrap();
    let mut rows = delta_rows::DeltaRows::default();
    rows.extend_from_slice(&[-0.0, 1.0, 2.0]);
    fastrand::seed(20261030);
    match rows.mapped() {
        Ok(mapped) => { assert_eq!(&*rows, &*mapped); println!("production DeltaRows::mapped succeeded"); }
        Err(e) => println!("production DeltaRows::mapped: {e:?}"),
    }
    fastrand::seed(20261030);
    let private = tempfile::tempdir_in(root.path())?;
    assert_ne!(occupied.path(), private.path());
    let file = tempfile::tempfile_in(private.path())?;
    println!("private-directory file creation succeeded: {} bytes", file.metadata()?.len());
    Ok(())
}

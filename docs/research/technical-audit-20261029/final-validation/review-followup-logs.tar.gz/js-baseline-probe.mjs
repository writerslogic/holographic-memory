import { HmsStore } from './js-baseline/dist/index.js'
import { mkdtempSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
const text = Array.from({ length: 100 }, (_, i) => `wörd${i}`).join(' ')
const store = new HmsStore({ path: mkdtempSync(join(tmpdir(), 'hms-recall-probe-')), dimensions: 1024, chunkWords: 20, overlapWords: 5,
  rerank: async (_query, passages) => {
    await store.memory.memorizeDocument({ id: 'x', text: 'short', storeText: true,
      metadata: { parity: 0, _hms_collection: '' },
      embeddings: (await store.embedder.encodeDocuments(['short'])).map(v => Array.from(v)),
    })
    return passages.map((_, i) => passages.length - i)
  },
})
try {
  await store.remember([{ id: 'x', text, metadata: { parity: 1 } }])
  const hits = await store.recall('wörd99', { k: 1, filter: { parity: 1 } })
  console.log(JSON.stringify({ filter: { parity: 1 }, hits, bytes: hits.map(h => Buffer.byteLength(h.text)) }, null, 2))
} finally { await store.close() }

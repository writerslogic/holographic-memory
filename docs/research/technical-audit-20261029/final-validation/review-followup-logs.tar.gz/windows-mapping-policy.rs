use std::ffi::c_void;
use std::io::{self, Write};
use std::os::windows::io::AsRawHandle;

#[link(name = "kernel32")]
extern "system" {
    fn SetProcessMitigationPolicy(policy: i32, buffer: *const c_void, len: usize) -> i32;
    fn CreateFileMappingW(file: *mut c_void, attrs: *mut c_void, protect: u32, high: u32, low: u32, name: *const u16) -> *mut c_void;
    fn CloseHandle(handle: *mut c_void) -> i32;
}

fn main() -> io::Result<()> {
    if std::env::args().any(|arg| arg == "--prohibit-dynamic-code") {
        let flags = 1u32;
        assert_ne!(unsafe { SetProcessMitigationPolicy(2, (&flags as *const u32).cast(), 4) }, 0, "{}", io::Error::last_os_error());
    }
    for len in [1, 1023, 1024, 1025] {
        let mut file = tempfile::tempfile()?;
        file.write_all(&vec![0; len * 4])?;
        for protection in [2, 4, 0x20, 0x40] {
            let h = unsafe { CreateFileMappingW(file.as_raw_handle(), std::ptr::null_mut(), protection, 0, 0, std::ptr::null()) };
            if h.is_null() {
                println!("len={len} protect={protection:#x}: {}", io::Error::last_os_error());
            } else {
                println!("len={len} protect={protection:#x}: success");
                assert_ne!(unsafe { CloseHandle(h) }, 0);
            }
        }
        for no_probe in [false, true] {
            let mut opts = memmap2::MmapOptions::new();
            if no_probe { opts.no_probe_handle(); }
            match unsafe { opts.map(&file) } {
                Ok(map) => { assert_eq!(map.len(), len * 4); println!("len={len} no_probe={no_probe}: success"); }
                Err(error) => println!("len={len} no_probe={no_probe}: {error}"),
            }
        }
    }
    Ok(())
}

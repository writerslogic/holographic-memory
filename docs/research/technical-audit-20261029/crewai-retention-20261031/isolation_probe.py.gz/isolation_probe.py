import json
import tempfile
import socket

_original_connect = socket.socket.connect
def local_only(self, address):
    if isinstance(address, tuple) and address[0] not in ('127.0.0.1', '::1', 'localhost'):
        raise RuntimeError('External network forbidden by local probe')
    return _original_connect(self, address)
socket.socket.connect = local_only

import chromadb
from chromadb.config import System
import pytest

attempts = []
def reject_system(self, *args, **kwargs):
    attempts.append('System')
    raise RuntimeError('Chroma system construction forbidden by WARM probe')

System.__init__ = reject_system
with tempfile.TemporaryDirectory() as directory:
    try:
        chromadb.PersistentClient(path=directory)
    except RuntimeError as exc:
        assert 'forbidden by WARM probe' in str(exc)
    else:
        raise AssertionError('Positive control did not activate')
assert attempts == ['System'], attempts
attempts.clear()
result = pytest.main(['-q', '-rs', '--disable-warnings', 'integrations/python/tests/crewai/test_crewai.py'])
assert result == 0, result
assert attempts == [], attempts
print(json.dumps({'chromadb': chromadb.__version__, 'chroma_system_constructions': len(attempts), 'positive_control_constructions': 1}))
